const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();

// Mock user data
let users = [];

// Middleware to check if the user is authenticated
function isAuthenticated(req, res, next) {
    if (req.session.user) {
        return next();
    }
    res.redirect('/login');
}

// GET: Registration page
router.get('/register', (req, res) => {
    res.render('register.ejs');
});

// POST: Handle user registration
router.post('/register', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.send('Username and password are required!');
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Save user
    users.push({ username, password: hashedPassword });
    console.log('Users:', users);

    res.redirect('/login');
});

// GET: Login page
router.get('/login', (req, res) => {
    res.render('login');
});

// POST: Handle user login
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username);

    if (!user) {
        return res.send('Invalid username or password.');
    }

    // Check password
    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
        return res.send('Invalid username or password.');
    }

    // Store user session
    req.session.user = user;
    res.redirect('/dashboard');
});

// GET: Dashboard (protected route)
router.get('/dashboard', isAuthenticated, (req, res) => {
    res.render('dashboard', { user: req.session.user });
});

// GET: Logout
router.get('/logout', (req, res) => {
    req.session.destroy(() => {
        res.redirect('/login');
    });
});

module.exports = router;
