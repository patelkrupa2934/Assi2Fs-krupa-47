const express = require('express');
const multer = require('multer');
const User = require('../models/usermodel');
const path = require('path'); // Import path module
const router = express.Router();

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, path.join(__dirname, '..', 'uploads'));  // Ensure cross-platform paths
    },
    filename: function (req, file, cb) {
        cb(null, new Date().toISOString().replace(/:/g, '-') + '-' + file.originalname); // Avoid colon in filenames
    }
});

const upload = multer({ storage: storage }); // Define upload here

// Get the form
router.get('/', (req, res) => {
    res.render('index');
});

// Handle form submission
router.post('/register', upload.array('files', 10), async (req, res) => {
    try {
        const newUser = new User({
            name: req.body.name,
            email: req.body.email,
            files: req.files.map(file => file.path)
        });

        await newUser.save();
        res.redirect('/files');
    } catch (error) {
        res.status(400).send('Error uploading files');
    }
});

// List uploaded files
router.get('/files', async (req, res) => {
    const users = await User.find();
    res.render('files', { users });
});

// Download a file
router.get('/download/:filename', (req, res) => {
    const filePath = path.join(__dirname, '..', 'uploads', req.params.filename);
    res.download(filePath);
});

module.exports = router;
