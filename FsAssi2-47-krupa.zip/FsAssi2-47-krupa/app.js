const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const userRoutes = require('./routes/userRoutes');
const path = require('path');
const fs = require('fs');

dotenv.config();
const app = express();

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/uploads', express.static('uploads'));  // Serve uploaded files

// MongoDB connection
mongoose.connect(process.env.DB_URL, { useNewUrlParser: true, useUnifiedTopology: true });

app.use('/', userRoutes); // Use userRoutes for handling all user-related routes

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

const uploadDir = './uploads';

// Check if 'uploads' folder exists, if not, create it
if (!fs.existsSync(uploadDir)){
    fs.mkdirSync(uploadDir);
    console.log('Uploads folder created.');
} else {
    console.log('Uploads folder already exists.');
}
