const express = require('express');
const multer = require('multer');
const User = require('../models/userModel');
const router = express.Router();
const upload = multer({ dest: 'uploads/' }); // Directory to store uploaded files

// User registration route
router.post('/register', upload.array('files'), async (req, res) => {
    const { name, email } = req.body;
    const files = req.files.map(file => file.path); // Get file paths
    const user = new User({ name, email, files });
    await user.save();
    res.redirect('/files');
});

// Route to display uploaded files
router.get('/files', async (req, res) => {
    const users = await User.find();
    res.render('files', { users });
});

// Route to download files
router.get('/download/:filename', (req, res) => {
    const file = `${__dirname}/../uploads/${req.params.filename}`;
    res.download(file);
});

module.exports = router;
